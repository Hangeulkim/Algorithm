#include<bits/stdc++.h>

using namespace std;

typedef struct POS{
    int x;
    int y;
}pos;

int n,k,x,y;
int btm=1,top;
vector<int> input[10001];

double dis(pos a, pos b){
    return ceil(sqrt(pow(a.x-b.x,2)+pow(a.y-b.y,2))/10);
}

bool bfs(int mid){
      bool chk[10001];

}

int main(){
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);

    cin>>n>>k;
    pos S={0,0};
    pos T={10000,10000};

    input.push_back(S);
    for(int i=0;i<n;i++){
        cin>>x>>y;
        input.push_back({x,y});
    }
    input.push_back(T);

    top=dis(S,T);
    int result=top;

    while(btm<=top){
        int mid=(btm+top)/2;

        if(bfs(mid)){
            top=mid-1;
            result=min(mid,result);
        }
        else
            btm=mid+1;
    }
    cout<<result<<'\n';

    return 0;
}
